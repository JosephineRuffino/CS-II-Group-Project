/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainprogram;

import java.util.*;

/**
 *
 * @author Noe
 */
public class Invoice {
    
    private int InvoiceID;
    
    private Customer c;
    private LinkedList <Service> ServiceData = new LinkedList<Service>();
    private LinkedList <HardwareProducts> ProductHData = new LinkedList<HardwareProducts>();
    private ArrayList <SoftwareProducts> ProductSData = new ArrayList<SoftwareProducts>();

    private double Stotal, PHtotal, PStotal;
    private double subtotal;
    private double realtotal;
    

    public Invoice (int InvoiceID, Customer c, LinkedList ServiceData, LinkedList ProductHData)
    {
        this.c = c;
        this.InvoiceID = InvoiceID;
        this.ServiceData = ServiceData;
        this.ProductHData = ProductHData;

        for(int i = 0; i < ServiceData.size(); i++)
        {
           Service s = (Service) ServiceData.get(i);
           Stotal = Stotal + s.getServiceCharge();
        }
        
        for(int j = 0; j < ProductHData.size(); j++)
        {
           HardwareProducts ph = (HardwareProducts) ProductHData.get(j);
           PHtotal = PHtotal + ph.getProductPrice();
           j++;
        }
        
        subtotal = (Stotal + PHtotal) * 0.05125;
        realtotal = Stotal + PHtotal + subtotal;
        
        
    }
    public Invoice (int InvoiceID, Customer c, LinkedList ServiceData, ArrayList ProductSData)
    {
        this.c = c;
        this.InvoiceID = InvoiceID;
        this.ServiceData = ServiceData;
        this.ProductSData = ProductSData;
        
        for(int i = 0; i < ServiceData.size(); i++)
        {
           Service s = (Service) ServiceData.get(i);
           Stotal = Stotal + s.getServiceCharge();
        }
        
        for(int j = 0; j < ProductSData.size(); j++)
        {
           SoftwareProducts sh = (SoftwareProducts) ProductSData.get(j);
           PStotal = PStotal + sh.getProductPrice();
        }
        
        subtotal = (Stotal + PStotal) * 0.05125;
        realtotal = Stotal + PStotal + subtotal;
    }
    public Invoice (int InvoiceID, Customer c, LinkedList ServiceData, LinkedList ProductHData, ArrayList ProductSData)
    {
        this.c = c;
        this.InvoiceID = InvoiceID;
        this.ServiceData = ServiceData;
        this.ProductSData = ProductSData;
        this.ProductHData = ProductHData;
        
        for(int i = 0; i < ServiceData.size(); i++)
        {
           Service s = (Service) ServiceData.get(i);
           Stotal = Stotal + s.getServiceCharge();
        }
        
        for(int j = 0; j < ProductHData.size(); j++)
        {
           HardwareProducts ph = (HardwareProducts) ProductHData.get(j);
           PHtotal = PHtotal + ph.getProductPrice();
        }
        
        for(int k = 0; k < ProductSData.size(); k++)
        {
           SoftwareProducts sh = (SoftwareProducts) ProductSData.get(k);
           PStotal = PStotal + sh.getProductPrice();
        }
        
        subtotal = (Stotal + PHtotal + PStotal) * 0.05125;
        realtotal = Stotal + PHtotal + PStotal + subtotal;
        
    }
    
    public String toString()
    {
        String line = "";
        
       if (ProductSData == null)
       {
           line += "Invoice number: " + InvoiceID + "\n\nCustomer:\n" + c.getFName() + " " + c.getLName() + " \n" + c.getStreetNumber() + " " + c.getStreetName() + "\n" + c.getPhoneNumber() + "\n\n"; 
           
           line += "Service(s): \n";
           
           for(int i = 0; i < ServiceData.size(); i++)
            {
                Service s = (Service) ServiceData.get(i);
                line += s.getServiceType() + " " + s.getServiceCharge() + "\n";
            }
           line += "\nProduct(s): \n";
           for(int j = 0; j < ProductHData.size(); j++)
            {
                HardwareProducts ph = (HardwareProducts) ProductHData.get(j);
                line += ph.getHardwareName() +" " + ph.getProductPrice() + "\n";
            }
           
           line += "\n Total: " + realtotal;
           
           return line;
       }
       else if (ProductHData == null)
       {
           line += "Invoice number: " + InvoiceID + "\n\nCustomer:\n" + c.getFName() + " " + c.getLName() + " \n" + c.getStreetNumber() + " " + c.getStreetName() + "\n" + c.getPhoneNumber() + "\n\n"; 
           
           line += "Service(s): \n";
           
           for(int i = 0; i < ServiceData.size(); i++)
            {
                Service s = (Service) ServiceData.get(i);
                line += s.getServiceType() + " " + s.getServiceCharge() + "\n";
            }
           line += "\nProduct(s): \n";
           for(int j = 0; j < ProductSData.size(); j++)
            {
                SoftwareProducts sh = (SoftwareProducts) ProductSData.get(j);
                line += sh.getSoftwareName() + " " + sh.getProductPrice() + "\n";
            }
           
           line += "\n Total: " + realtotal;
           
           return line;
       }
       else
       {
          line += "Invoice number: " + InvoiceID + "\n\nCustomer:\n" + c.getFName() + " " + c.getLName() + " \n" + c.getStreetNumber() + " " + c.getStreetName() + "\n" + c.getPhoneNumber() + "\n\n"; 
           
          line += "Service(s): \n";
          
           for(int i = 0; i < ServiceData.size(); i++)
            {
                Service s = (Service) ServiceData.get(i);
                line += s.getServiceType() + " " + s.getServiceCharge() + "\n";
            }
           line += "\nProduct(s): \n";
           for(int j = 0; j < ProductHData.size(); j++)
            {
                HardwareProducts ph = (HardwareProducts) ProductHData.get(j);
                line += ph.getHardwareName() +" " + ph.getProductPrice() + "\n";
            }
           line += "\n \n";
           for(int k = 0; k < ProductSData.size(); k++)
            {
                SoftwareProducts sh = (SoftwareProducts) ProductSData.get(k);
                line += sh.getSoftwareName() + " " + sh.getProductPrice() + "\n";
            }
           
           line += "\n Total: " + realtotal;
           
           return line; 
       }
     
    }
        
    public double getTotal()
    {
        return realtotal;
    }
    
    public String getID()
    {
        return String.valueOf(InvoiceID);
    }
    
    public String getCustomerName()
    {
        return c.getFName();
    }
    public String getCustomerLastName()
    {
        return c.getLName();
    }
    
    public String getServices()
    {   
        String line="Services: \n";
        
        for(int i = 0; i < ServiceData.size(); i++)
            {
                Service s = (Service) ServiceData.get(i);
                line += s.getServiceType() + " " + s.getServiceCharge() + "\n";
            }
        return line;
    }
    
    public String getHardwareProducts()
    {   
        String line="Hardware Products: \n";
        
        for(int i = 0; i < ProductHData.size(); i++)
            {
                HardwareProducts hp = (HardwareProducts) ProductHData.get(i);
                line += hp.getHardwareName() + " " + hp.getProductPrice() + "\n";
            }
        return line;
    }
    
    public String getSoftwareProducts()
    {   
        String line="Software Products: " + ProductSData.size();
        
        for(int i = 0; i < ProductSData.size(); i++)
            {
                SoftwareProducts sp = (SoftwareProducts) ProductSData.get(i);
                line += sp.getSoftwareName() + " " + sp.getProductPrice() + "\n";
            }
        return line;
    }
    
   
}
