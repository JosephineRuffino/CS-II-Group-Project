/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainprogram;


/**
 *
 * @author NotoriousOne
 */
public class Product {
    
    //create variables
    protected int productID;
    protected double productPrice;

    
    public Product (int productID, double productPrice) //construct the product class 
	{
	this.productID=productID;
	this.productPrice=productPrice;
    }
    public int productID() // returns a product price
    {
        return productID;
    }

    public void modify(int productID, double productPrice) //construct a product after new inputs are entered
    {
        this.productPrice = productPrice;
    }

    public double getProductPrice() // returns a product price
    {
        return productPrice;
    }

    
    public String toString() //constructs and prints the sentence for a product
    {
        return productID + "," + productPrice;
    }
    
}
