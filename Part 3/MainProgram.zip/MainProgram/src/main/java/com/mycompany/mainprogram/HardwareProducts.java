/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainprogram;

/**
 *
 * @author josep
 */
public class HardwareProducts extends Product {
    //create variables	
        private String hardwareName;   
	public HardwareProducts (int productID,  double productPrice, String hardwareName) //construct the product class 
	{
		super(productID, productPrice);
                this.hardwareName = hardwareName;
	}
	
	public void modify (String hardwareName, double productPrice) //construct a product after new inputs are entered
	{
		this.productPrice= productPrice; 
                this.hardwareName= hardwareName;
        
        }
	public double getProductPrice() // returns a product price 
	{
		return productPrice;
	}
        public String getHardwareName() // returns a hardware name
	{
		return hardwareName;
	}
        @Override
	public String toString()
	{
		return productID + ","  + productPrice + ","+ hardwareName;
	}

    /**
     * @param hardwareName the hardwareName to set
     */
    public void setHardwareName(String hardwareName) {
        this.hardwareName = hardwareName;
    }
}
