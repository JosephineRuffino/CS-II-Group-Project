/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainprogram;

/**
 *
 * @author josep
 */
public class SoftwareProducts extends Product {
    //vaiables are same as HardwareProducts
    String softwareName;  

    /**
     * @return the softwareName
     */
    public String getSoftwareName() {
        return softwareName;
    }

    /**
     * @param softwareName the softwareName to set
     */
    
    
	public SoftwareProducts (int productID,  double productPrice, String softwareName) //construct the product class 
	{
            super(productID, productPrice);
            this.softwareName = softwareName;
	}
        public void setSoftwareName(String softwareName) {
            this.softwareName = softwareName;
        }
	
	public void modify (double productPrice, String softwareName) //construct a product after new inputs are entered
	{
		this.productPrice= productPrice; 
                this.softwareName = softwareName; 
	}
        
	
	public double getProductPrice() // returns a product price 
	{
		return productPrice;
	}
        public double getProductID() // returns a product price 
	{
		return productID;
	}
       
       
        
        @Override
        
	public String toString()
	{
		return productID + "," + getSoftwareName() +  "," + productPrice;
	}

   
    
}
