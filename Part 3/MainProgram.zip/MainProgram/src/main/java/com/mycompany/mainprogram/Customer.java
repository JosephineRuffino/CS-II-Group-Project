/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainprogram;

/**
 *
 * @author NotoriousOne
 */
public class Customer{
    //create variables
    private int customerId,streetNumber;
    private long phoneNumber;
    private String fName, lName, streetName;
  		//construct the customer class 
		public Customer(int customerId, String fName, String lName, int streetNumber, String streetName, long phoneNumber){
		
			this.customerId =customerId;
			this.fName =fName;
			this.lName= lName;
			this.streetName = streetName;
			this.streetNumber= streetNumber;
			this.phoneNumber =phoneNumber;
		}
		
		public void modify (String fName, String lName, int streetNumber, String streetName, long phoneNumber)
		{ //construct a customer after new inputs are entered 
			this.fName =fName;
			this.lName= lName;
			this.streetNumber= streetNumber;
			this.streetName = streetName;
			this.phoneNumber =phoneNumber;
		}
                public int getCustomerId() //resturns Customer ID 
		{
			return customerId;
		}
                public String getFName() //resturns Customer's first name  
		{
			return fName;
		}
                public String getLName() //resturns Customer's  last name  
		{
			return lName;
		}
                public String getStreetName() //resturns Customer's  street name  
		{
			return streetName;
		}
                public int getStreetNumber() //resturns Customer's  street number 
		{
			return streetNumber;
		}
                public long getPhoneNumber() //resturns Customer's  phone number 
		{
			return phoneNumber;
		}
                

		public String toString()
		{ //print the cutsomer's information in a sentence 
			return customerId + ","+ fName+ ","+ lName+ ","+ streetNumber+ ","+ streetName + "," + phoneNumber;
		}
}