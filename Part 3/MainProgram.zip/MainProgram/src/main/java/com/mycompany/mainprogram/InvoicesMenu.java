/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.mainprogram;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author noe_s
 */
public class InvoicesMenu extends javax.swing.JFrame {
    String ServicesFile = "Services.dat";
    private Map<Integer, Service> ServicesData;
    
    String CustomersFile = "Customers.dat";
    private Map<Integer, Customer> CustomerData;
    
    String HardwareProductFile = "HardwareProduct.dat";
    private Map<Integer, HardwareProducts> HardwareProductData;
    
    String SoftwareProductFile = "SoftwareProduct.dat";
    private Map<Integer,SoftwareProducts> SoftwareProductData ;
    
    private Map<Integer, Invoice> InvoicesData;
    
    private Customer c;
    private int InvoiceID;
    private String Display;
    
    private LinkedList<Service> ServicesDataList;
    private LinkedList<HardwareProducts> ProductHData;
    private ArrayList<SoftwareProducts> ProductSData;
    
    /**
     * Creates new form InvoicesMenu
     */
    public InvoicesMenu() {
        CustomerData = new TreeMap<Integer, Customer>();
        downloadCustomers();
        
        ServicesData = new TreeMap<Integer, Service>(); 
        downloadServices();
        ServicesDataList = new LinkedList<Service>();
        
        HardwareProductData = new TreeMap<Integer, HardwareProducts>();
        downloadHardwareProducts();
        ProductHData = new LinkedList<HardwareProducts>();
        
        SoftwareProductData = new TreeMap<Integer, SoftwareProducts>();
        downloadSoftwareProducts();
        ProductSData = new ArrayList<SoftwareProducts>();
        
        InvoicesData = new TreeMap<Integer, Invoice>();
        
        initComponents();
        
        txtDisplayInvoice.setEditable(false);
        txtPrintInvoice.setEditable(false);
        
        //Updatebtn.setVisible(false);
        
        
        clearDefault();

    }
    
    private void clearDefault()
    {
        
        Servicebtn.setVisible(false);
        Softwarebtn.setVisible(false);
        Customerbtn.setVisible(false);
        Hardwarebtn.setVisible(false);
        
        LookupCustomerbtn.setVisible(false);
        LookupServicesbtn.setVisible(false);
        
        txtCustomer.setVisible(false);
        txtService.setVisible(false);
        txtProduct.setVisible(false);
        
        ProductSbtn.setVisible(false);
        ProductHbtn.setVisible(false);
        LookupProductsSbtn.setVisible(false);
        LookupProductsHbtn.setVisible(false);
        
        DoneSbtn.setVisible(false);
        DonePbtn.setVisible(false);
        DonePbtn.setVisible(false);
        
        Createbtn.setVisible(false);
    }
    
    private void downloadCustomers()
    {
        String Customer;
        
        try
        {
            FileReader r = new FileReader(CustomersFile);
            BufferedReader reader = new BufferedReader(r);
            
            while ((Customer = reader.readLine()) != null)
            {
                if (Customer.length() > 0)
                {
                String cData[] = Customer.split(",");
                
                int id = Integer.valueOf(cData[0]);
                String fName = cData[1];
                String lName = cData[2];
                int streetNumber = Integer.valueOf(cData[3]);
                String streetName = cData[4];
                long phoneNumber = Long.valueOf(cData[5]);
                
                Customer cs = new Customer(id, fName, lName, streetNumber, streetName, phoneNumber);
                
                CustomerData.put(id, cs);
                   
                }
            }
            reader.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "file error");
        }
    }
    
    private void downloadServices()
    {
        String Service;
        
        try
        {
            FileReader r = new FileReader(ServicesFile);
            BufferedReader reader = new BufferedReader(r);
            
            while ((Service = reader.readLine()) != null)
            {
                if (Service.length() > 0)
                {
                String sData[] = Service.split(",");
                
                int id = Integer.valueOf(sData[0]);
                String type = sData[1];
                double charge = Double.valueOf(sData[2]);
                
                Service s = new Service(id, type, charge);
                
                ServicesData.put( id, s);
                   
                }
            }
            reader.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "file error");
        }
    }
    
    private void downloadHardwareProducts()
    {
        String HardwareProduct;
        
        try
        {
            FileReader r = new FileReader(HardwareProductFile);
            BufferedReader reader = new BufferedReader(r);
            
            while ((HardwareProduct = reader.readLine()) != null)
            {
                if (HardwareProduct.length() > 0)
                {
                String pData[] = HardwareProduct.split(",");
                
                int id = Integer.valueOf(pData[0]);
                String hardwareName = pData[2];
                double price = Double.valueOf(pData[1]);
                
                HardwareProducts p = new HardwareProducts(id,  price, hardwareName);
                
                HardwareProductData.put(id, p);
                   
                }
            }
            reader.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "file error");
        }
    }
    
    private void downloadSoftwareProducts()
    {
        String SoftwareProducts;
        
        try
        {
            FileReader r = new FileReader(SoftwareProductFile);
            BufferedReader reader = new BufferedReader(r);
            
            while ((SoftwareProducts = reader.readLine()) != null)
            {
                if (SoftwareProducts.length() > 0)
                {
                String sData[] = SoftwareProducts.split(",");
                
                int id = Integer.valueOf(sData[0]);
                String softwareName = sData[1];
                double price = Double.valueOf(sData[2]);
                
                SoftwareProducts sw = new SoftwareProducts(id, price, softwareName);
               
                SoftwareProductData.put(id, sw);
                   
                }
            }
            reader.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "file error");
        }
    }
    
    private void InvoiceTable()
    {
        for(Object value : InvoicesData.keySet())
        {
            Invoice in = (Invoice) InvoicesData.get(value);
            
            DefaultTableModel model = (DefaultTableModel)tblInvoices.getModel();
                
                Vector row = new Vector();
                    row.add(in.getID());
                    row.add(in.getCustomerName());
                    row.add(in.getCustomerLastName());
                    row.add(in.getTotal());
                   
                    model.addRow(row);
        }
        int rows = tblInvoices.getRowCount();
       
    }
    
    private void clearInvoiceTable()
    {
       
            ((DefaultTableModel)tblInvoices.getModel()).setRowCount(0);
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ProductType = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtInvoiceID = new javax.swing.JTextField();
        ProductHbtn = new javax.swing.JButton();
        txtProduct = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtCustomer = new javax.swing.JTextField();
        Invoicebtn = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Softwarebtn = new javax.swing.JRadioButton();
        Hardwarebtn = new javax.swing.JRadioButton();
        Servicebtn = new javax.swing.JButton();
        LookupServicesbtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDisplayInvoice = new javax.swing.JTextArea();
        LookupCustomerbtn = new javax.swing.JButton();
        txtService = new javax.swing.JTextField();
        ProductSbtn = new javax.swing.JButton();
        LookupProductsHbtn = new javax.swing.JButton();
        Customerbtn = new javax.swing.JButton();
        DonePbtn = new javax.swing.JButton();
        DoneSbtn = new javax.swing.JButton();
        Cancelbtn = new javax.swing.JButton();
        LookupProductsSbtn = new javax.swing.JButton();
        Createbtn = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblInvoices = new javax.swing.JTable();
        Updatebtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtPrintInvoiceID = new javax.swing.JTextField();
        InvoiceClearbtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtPrintInvoice = new javax.swing.JTextArea();
        InvoicePrintbtn = new javax.swing.JButton();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Agency FB", 1, 36)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INVOICES.fw.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, -1, -1));

        jTabbedPane1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jTabbedPane1StateChanged(evt);
            }
        });
        jTabbedPane1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTabbedPane1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTabbedPane1FocusLost(evt);
            }
        });

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel2.setText("Product");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 100, -1));

        jLabel3.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel3.setText("Invoice ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 130, -1));

        txtInvoiceID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtInvoiceIDKeyPressed(evt);
            }
        });
        jPanel1.add(txtInvoiceID, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 90, -1));

        ProductHbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        ProductHbtn.setText("Add");
        ProductHbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductHbtnActionPerformed(evt);
            }
        });
        jPanel1.add(ProductHbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, -1, -1));

        txtProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProductActionPerformed(evt);
            }
        });
        txtProduct.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtProductKeyPressed(evt);
            }
        });
        jPanel1.add(txtProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 90, -1));

        jLabel4.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel4.setText("Customer");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 120, -1));

        txtCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCustomerActionPerformed(evt);
            }
        });
        txtCustomer.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCustomerKeyPressed(evt);
            }
        });
        jPanel1.add(txtCustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 90, -1));

        Invoicebtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        Invoicebtn.setText("Add");
        Invoicebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InvoicebtnActionPerformed(evt);
            }
        });
        jPanel1.add(Invoicebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 40, -1, -1));

        jLabel5.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel5.setText("Services");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 90, -1));

        ProductType.add(Softwarebtn);
        Softwarebtn.setText("Software");
        Softwarebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SoftwarebtnActionPerformed(evt);
            }
        });
        jPanel1.add(Softwarebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 150, -1, -1));

        ProductType.add(Hardwarebtn);
        Hardwarebtn.setText("Hardware");
        Hardwarebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HardwarebtnActionPerformed(evt);
            }
        });
        jPanel1.add(Hardwarebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 180, -1, -1));

        Servicebtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        Servicebtn.setText("Add");
        Servicebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ServicebtnActionPerformed(evt);
            }
        });
        jPanel1.add(Servicebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, -1, -1));

        LookupServicesbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        LookupServicesbtn.setText("Search Services");
        LookupServicesbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LookupServicesbtnActionPerformed(evt);
            }
        });
        jPanel1.add(LookupServicesbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 120, 150, -1));

        txtDisplayInvoice.setColumns(20);
        txtDisplayInvoice.setRows(5);
        jScrollPane1.setViewportView(txtDisplayInvoice);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, 280, 140));

        LookupCustomerbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        LookupCustomerbtn.setText("Search Customers");
        LookupCustomerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LookupCustomerbtnActionPerformed(evt);
            }
        });
        jPanel1.add(LookupCustomerbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, 150, -1));

        txtService.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtServiceKeyPressed(evt);
            }
        });
        jPanel1.add(txtService, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 90, -1));

        ProductSbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        ProductSbtn.setText("Add");
        ProductSbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductSbtnActionPerformed(evt);
            }
        });
        jPanel1.add(ProductSbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, -1, -1));

        LookupProductsHbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        LookupProductsHbtn.setText("Search Products");
        LookupProductsHbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LookupProductsHbtnActionPerformed(evt);
            }
        });
        jPanel1.add(LookupProductsHbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 160, 150, -1));

        Customerbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        Customerbtn.setText("Add");
        Customerbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustomerbtnActionPerformed(evt);
            }
        });
        jPanel1.add(Customerbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, -1, -1));

        DonePbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        DonePbtn.setText("Done");
        DonePbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DonePbtnActionPerformed(evt);
            }
        });
        jPanel1.add(DonePbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, 70, -1));

        DoneSbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        DoneSbtn.setText("Done");
        DoneSbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DoneSbtnActionPerformed(evt);
            }
        });
        jPanel1.add(DoneSbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 70, -1));

        Cancelbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        Cancelbtn.setText("CANCEL");
        Cancelbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelbtnActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 390, 80, -1));

        LookupProductsSbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        LookupProductsSbtn.setText("Search Products");
        LookupProductsSbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LookupProductsSbtnActionPerformed(evt);
            }
        });
        jPanel1.add(LookupProductsSbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 160, 150, -1));

        Createbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        Createbtn.setText("GENERATE");
        Createbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreatebtnActionPerformed(evt);
            }
        });
        jPanel1.add(Createbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 390, 90, -1));

        jTabbedPane1.addTab("Generate", jPanel1);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblInvoices.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Invoice ID", "Name", "Last Name", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tblInvoices);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 390, 190));

        Updatebtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        Updatebtn.setText("UPDATE");
        Updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdatebtnActionPerformed(evt);
            }
        });
        jPanel3.add(Updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, -1, -1));

        jTabbedPane1.addTab("Generated Invoices", jPanel3);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel6.setText("Invoice ID");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 100, -1));

        txtPrintInvoiceID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrintInvoiceIDActionPerformed(evt);
            }
        });
        jPanel2.add(txtPrintInvoiceID, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 30, 90, -1));

        InvoiceClearbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        InvoiceClearbtn.setText("CLEAR");
        InvoiceClearbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InvoiceClearbtnActionPerformed(evt);
            }
        });
        jPanel2.add(InvoiceClearbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 20, -1, -1));

        txtPrintInvoice.setColumns(20);
        txtPrintInvoice.setRows(5);
        jScrollPane2.setViewportView(txtPrintInvoice);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, 350, 340));

        InvoicePrintbtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        InvoicePrintbtn.setText("PRINT");
        InvoicePrintbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InvoicePrintbtnActionPerformed(evt);
            }
        });
        jPanel2.add(InvoicePrintbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 20, -1, -1));

        jTabbedPane1.addTab("Print", jPanel2);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 490, 460));

        setSize(new java.awt.Dimension(533, 599));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CancelbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelbtnActionPerformed
        
        ServicesDataList = new LinkedList<Service>();
        ProductHData = new LinkedList<HardwareProducts>();
        ProductSData = new ArrayList<SoftwareProducts>();
        
        InvoiceID = 0;
        
        txtDisplayInvoice.setText("");
        
        txtInvoiceID.setEditable(true);
        txtCustomer.setEditable(true);
        txtService.setEditable(true);
        
        txtInvoiceID.setText("");
        txtCustomer.setText("");
        txtService.setText("");
        txtProduct.setText("");
        
        Invoicebtn.setVisible(true);
        
        clearDefault();
    }//GEN-LAST:event_CancelbtnActionPerformed

    private void CreatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreatebtnActionPerformed
        
        if(ProductSData == null)
        {
            Invoice i = new Invoice(InvoiceID, c, ServicesDataList, ProductHData);
            InvoicesData.put(InvoiceID, i);

        }
        else if(ProductHData == null)
        {
            Invoice i = new Invoice(InvoiceID, c, ServicesDataList, ProductSData);
            InvoicesData.put(InvoiceID, i);

        }
        else 
        {
            Invoice i = new Invoice(InvoiceID, c, ServicesDataList, ProductHData, ProductSData);
            InvoicesData.put(InvoiceID, i);

        }
        
        ServicesDataList = new LinkedList<Service>();
        ProductHData = new LinkedList<HardwareProducts>();
        ProductSData = new ArrayList<SoftwareProducts>();
        
        InvoiceID = 0;
        
        txtDisplayInvoice.setText("");
        
        txtInvoiceID.setEditable(true);
        txtCustomer.setEditable(true);
        txtService.setEditable(true);
        
        txtInvoiceID.setText("");
        txtCustomer.setText("");
        txtService.setText("");
        txtProduct.setText("");
        
        Invoicebtn.setVisible(true);
        
        Updatebtn.setVisible(true);
        
        ProductType.clearSelection();
        
        clearDefault();
        
        
        
        
    }//GEN-LAST:event_CreatebtnActionPerformed

    private void DoneSbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoneSbtnActionPerformed
        
        txtService.setEditable(false);
        Servicebtn.setVisible(false);
        DoneSbtn.setVisible(false);
        LookupServicesbtn.setVisible(false);
        
        Softwarebtn.setVisible(true);
        Hardwarebtn.setVisible(true);
        
        //Display box
        Display += "Service(s): \n";
        for(int i = 0; i < ServicesDataList.size(); i++)
        {
            Service s = (Service) ServicesDataList.get(i);
            Display += s.getServiceType() + " " + s.getServiceCharge() + "\n";
            txtDisplayInvoice.setText(Display);
        }
        
    }//GEN-LAST:event_DoneSbtnActionPerformed

    private void DonePbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DonePbtnActionPerformed
        
        Softwarebtn.setVisible(false);
        Hardwarebtn.setVisible(false);
        
        LookupProductsSbtn.setVisible(false);
        LookupProductsHbtn.setVisible(false);
        
        ProductHbtn.setVisible(false);
        ProductSbtn.setVisible(false);
        
        txtProduct.setVisible(false);
        
        DonePbtn.setVisible(false);
        
        Createbtn.setVisible(true);
        
        //Display box
        Display += "Product(s): \n";
        
        if (ProductSData == null)
        {
          for(int i = 0; i < ProductHData.size(); i++)
            {
                HardwareProducts hp = (HardwareProducts) ProductHData.get(i);
                Display += hp.getHardwareName() +" " + hp.getProductPrice() + "\n";
                txtDisplayInvoice.setText(Display);
            }  
        }
        else if (ProductHData == null)
        {
         for(int i = 0; i < ProductSData.size(); i++)
            {
                SoftwareProducts sp = (SoftwareProducts) ProductSData.get(i);
                Display += sp.getSoftwareName() +" " + sp.getProductPrice() + "\n";
                txtDisplayInvoice.setText(Display);
            }   
        }
        else
        {
           for(int i = 0; i < ProductHData.size(); i++)
            {
                HardwareProducts hp = (HardwareProducts) ProductHData.get(i);
                Display += hp.getHardwareName() +" " + hp.getProductPrice() + "\n";
                txtDisplayInvoice.setText(Display);
            } 
           for(int i = 0; i < ProductSData.size(); i++)
            {
                SoftwareProducts sp = (SoftwareProducts) ProductSData.get(i);
                Display += sp.getSoftwareName() +" " + sp.getProductPrice() + "\n";
                txtDisplayInvoice.setText(Display);
            }
        }
        
        
    }//GEN-LAST:event_DonePbtnActionPerformed

    private void CustomerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustomerbtnActionPerformed
        String Validation = txtInvoiceID.getText();
        int CustomerID = Integer.valueOf(txtCustomer.getText());
       
        if (CustomerData.get(CustomerID)== null){
            JOptionPane.showMessageDialog(InvoicesMenu.this, 
                                "CustomerId does not exist, please try again");  
        }
        else{

             c = (Customer) CustomerData.get(CustomerID);
             
        
             Customerbtn.setVisible(false);
             txtCustomer.setEditable(false);
             LookupCustomerbtn.setVisible(false);
        
             txtService.setVisible(true);
             Servicebtn.setVisible(true);
             LookupServicesbtn.setVisible(true);
        
             //Display box
             Display += "Customer: " + c.getCustomerId() +" " + c.getFName() + " " + c.getLName() + "\n";
             txtDisplayInvoice.setText(Display);
        }
       
        
        
    }//GEN-LAST:event_CustomerbtnActionPerformed

    private void LookupProductsHbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LookupProductsHbtnActionPerformed
        
        new HardwareProductsList().setVisible(true); 
        
        
    }//GEN-LAST:event_LookupProductsHbtnActionPerformed

    private void LookupCustomerbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LookupCustomerbtnActionPerformed

        new CustomersList().setVisible(true);

    }//GEN-LAST:event_LookupCustomerbtnActionPerformed

    private void LookupServicesbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LookupServicesbtnActionPerformed

        new ServicesList().setVisible(true);

    }//GEN-LAST:event_LookupServicesbtnActionPerformed

    private void HardwarebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HardwarebtnActionPerformed

        txtProduct.setVisible(true);

        ProductHbtn.setVisible(true);

        LookupProductsHbtn.setVisible(true);

        LookupProductsSbtn.setVisible(false);

        ProductSbtn.setVisible(false);

    }//GEN-LAST:event_HardwarebtnActionPerformed

    private void SoftwarebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SoftwarebtnActionPerformed

        txtProduct.setVisible(true);

        ProductSbtn.setVisible(true);

        LookupProductsSbtn.setVisible(true);

        LookupProductsHbtn.setVisible(false);

        ProductHbtn.setVisible(false);

    }//GEN-LAST:event_SoftwarebtnActionPerformed

    private void InvoicebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InvoicebtnActionPerformed

        String Validation = txtInvoiceID.getText();
        
        try
        {
            Integer.parseInt(Validation);
        
        
        if (Validation.length() > 4 || Validation.length() < 4)
        { 
          JOptionPane.showMessageDialog(InvoicesMenu.this, 
                                "InvoiceID should be 4 characters");  
        }else if (InvoicesData.get(InvoiceID) != null){
            JOptionPane.showMessageDialog(InvoicesMenu.this, 
                                "InvoiceID already exist, please try again");  
        }
        else
        {
            InvoiceID = Integer.valueOf(txtInvoiceID.getText());
            txtCustomer.setVisible(true);
            LookupCustomerbtn.setVisible(true);
            txtInvoiceID.setEditable(false);
            Invoicebtn.setVisible(false);
            Customerbtn.setVisible(true);
            
            //Display box
            Display = "Invoice ID: " + txtInvoiceID.getText() + "\n";
            txtDisplayInvoice.setText(Display);
        }
        }
        
        catch(NumberFormatException e)
        {
            JOptionPane.showMessageDialog(InvoicesMenu.this, 
                                "ID must be numbers"); 
        }
                
    }//GEN-LAST:event_InvoicebtnActionPerformed

    private void LookupProductsSbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LookupProductsSbtnActionPerformed

     new SoftwareProductsList().setVisible(true); 
        
    }//GEN-LAST:event_LookupProductsSbtnActionPerformed

    private void ServicebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicebtnActionPerformed
        
        int ServiceID = Integer.valueOf(txtService.getText());
        Service s = (Service) ServicesData.get(ServiceID);
        if (ServicesData.get(ServiceID) == null){
            JOptionPane.showMessageDialog(InvoicesMenu.this, 
                                "ServiceId does not exist, please try again");  
        }else{
            ServicesDataList.add(s);
        }
        
        txtService.setText("");
        DoneSbtn.setVisible(true);
        
    }//GEN-LAST:event_ServicebtnActionPerformed

    private void ProductSbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductSbtnActionPerformed
        
        int ProductID = Integer.valueOf(txtProduct.getText());
        SoftwareProducts sp = (SoftwareProducts) SoftwareProductData.get(ProductID);
        
        if (SoftwareProductData.get(ProductID) == null){
            JOptionPane.showMessageDialog(InvoicesMenu.this, 
                                "ProductID does not exist, please try again");  
        }else{
            
            ProductSData.add(sp);
        }
        
        
        txtProduct.setText("");
        DonePbtn.setVisible(true);
        
    }//GEN-LAST:event_ProductSbtnActionPerformed

    private void ProductHbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductHbtnActionPerformed
        
        int ProductID = Integer.valueOf(txtProduct.getText());
        HardwareProducts hp = (HardwareProducts) HardwareProductData.get(ProductID);
        if (HardwareProductData.get(ProductID)== null){
            JOptionPane.showMessageDialog(InvoicesMenu.this, 
                                "ProductID does not exist, please try again");  
        }else{
            
            ProductHData.add(hp);
        }
        
        
        txtProduct.setText("");
        DonePbtn.setVisible(true);
    }//GEN-LAST:event_ProductHbtnActionPerformed

    private void InvoiceClearbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InvoiceClearbtnActionPerformed
        
        txtPrintInvoice.setText("");
        txtPrintInvoiceID.setText("");
                
    }//GEN-LAST:event_InvoiceClearbtnActionPerformed

    private void InvoicePrintbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InvoicePrintbtnActionPerformed
        String Validation = txtInvoiceID.getText();
        
        int InvoiceID = Integer.valueOf(txtPrintInvoiceID.getText());
        if(InvoicesData.get(InvoiceID) == null){
            JOptionPane.showMessageDialog(InvoicesMenu.this, 
                                "InvoiceID does not exist, please try again"); 
            
        }else{
        Invoice i = (Invoice) InvoicesData.get(InvoiceID);
        txtPrintInvoice.setText(i.toString());
         txtPrintInvoiceID.setText("");
        
        }
        
        
       
        
    }//GEN-LAST:event_InvoicePrintbtnActionPerformed

    private void jTabbedPane1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jTabbedPane1StateChanged

    clearInvoiceTable();
       
    }//GEN-LAST:event_jTabbedPane1StateChanged

    private void jTabbedPane1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTabbedPane1FocusGained
    

       
    }//GEN-LAST:event_jTabbedPane1FocusGained

    private void jTabbedPane1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTabbedPane1FocusLost


    }//GEN-LAST:event_jTabbedPane1FocusLost

    private void UpdatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdatebtnActionPerformed
    
        clearInvoiceTable();
        InvoiceTable();
    }//GEN-LAST:event_UpdatebtnActionPerformed

    private void txtPrintInvoiceIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrintInvoiceIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrintInvoiceIDActionPerformed

    private void txtCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCustomerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCustomerActionPerformed

    private void txtInvoiceIDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtInvoiceIDKeyPressed
        char c = evt.getKeyChar();
        if (Character.isDigit(c)|| Character.isISOControl(c)){
            txtInvoiceID.setEditable(true);
        }else{ 
            txtInvoiceID.setEditable(false);
        
     }
    }//GEN-LAST:event_txtInvoiceIDKeyPressed

    private void txtCustomerKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCustomerKeyPressed
        char c = evt.getKeyChar();
        if (Character.isDigit(c)|| Character.isISOControl(c)){
            txtCustomer.setEditable(true);
        }else{ 
            txtCustomer.setEditable(false);
        
     }
    }//GEN-LAST:event_txtCustomerKeyPressed

    private void txtServiceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtServiceKeyPressed
        char c = evt.getKeyChar();
        if (Character.isDigit(c)|| Character.isISOControl(c)){
            txtService.setEditable(true);
        }else{ 
            txtService.setEditable(false);
        
     }
    }//GEN-LAST:event_txtServiceKeyPressed

    private void txtProductKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProductKeyPressed
        char c = evt.getKeyChar();
        if (Character.isDigit(c)|| Character.isISOControl(c)){
            txtProduct.setEditable(true);
        }else{ 
            txtProduct.setEditable(false);
     }  
         }//GEN-LAST:event_txtProductKeyPressed

    private void txtProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProductActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProductActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InvoicesMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InvoicesMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InvoicesMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InvoicesMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InvoicesMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancelbtn;
    private javax.swing.JButton Createbtn;
    private javax.swing.JButton Customerbtn;
    private javax.swing.JButton DonePbtn;
    private javax.swing.JButton DoneSbtn;
    private javax.swing.JRadioButton Hardwarebtn;
    private javax.swing.JButton InvoiceClearbtn;
    private javax.swing.JButton InvoicePrintbtn;
    private javax.swing.JButton Invoicebtn;
    private javax.swing.JButton LookupCustomerbtn;
    private javax.swing.JButton LookupProductsHbtn;
    private javax.swing.JButton LookupProductsSbtn;
    private javax.swing.JButton LookupServicesbtn;
    private javax.swing.JButton ProductHbtn;
    private javax.swing.JButton ProductSbtn;
    private javax.swing.ButtonGroup ProductType;
    private javax.swing.JButton Servicebtn;
    private javax.swing.JRadioButton Softwarebtn;
    private javax.swing.JButton Updatebtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tblInvoices;
    private javax.swing.JTextField txtCustomer;
    private javax.swing.JTextArea txtDisplayInvoice;
    private javax.swing.JTextField txtInvoiceID;
    private javax.swing.JTextArea txtPrintInvoice;
    private javax.swing.JTextField txtPrintInvoiceID;
    private javax.swing.JTextField txtProduct;
    private javax.swing.JTextField txtService;
    // End of variables declaration//GEN-END:variables
}
