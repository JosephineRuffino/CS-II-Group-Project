/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.mainprogram;

import java.io.BufferedReader;
import javax.swing.JOptionPane;
import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author josep
 */
public class ProductsMenu extends javax.swing.JFrame {
   
    String HardwareProductFile = "HardwareProduct.dat";
    private Map<Integer, HardwareProducts> HardwareProductData;
    
    String SoftwareProductFile = "SoftwareProduct.dat";
    private Map<Integer,SoftwareProducts> SoftwareProductData ;
    
    /**
     * Creates new form ProductsMenu
     */
    public ProductsMenu() {
        HardwareProductData = new TreeMap<Integer, HardwareProducts>();
        SoftwareProductData = new TreeMap<Integer, SoftwareProducts>();

        
        downloadHardwareProducts();
        downloadSoftwareProducts();
        initComponents();
        
  //text fields are not editable until you select "Hardware" or "Software" radio button
        btnCreate.setVisible(false);
        btnCancelC.setVisible(false);
        btnCreate2.setVisible(false);
        btnCancelC2.setVisible(false);
        
        btnUpdateHW.setVisible(false);
        btnUpdateSW.setVisible(false);
        btnCancelM.setVisible(false);
        btnCancelM2.setVisible(false);
        
        btnDeleteHW.setVisible(false);
        btnDeleteSW.setVisible(false);
        
        btnSearchHW.setVisible(false);
        btnSearchSW.setVisible(false);
        btnClearHW.setVisible(false);
        btnClearSW.setVisible(false);

        LookupSButton.setVisible(false);
        LookupHButton.setVisible(false);
        txtproductID.setEditable(false);
        txtproductName.setEditable(false);
        txtproductPrice.setEditable(false);
        txtproductNameM.setEditable(false);
        txtproductPriceM.setEditable(false);
        txtproductIDM.setEditable(false);
        txtproductIDD.setEditable(false);
        txtproductIDS.setEditable(false);
        txtproductPriceS.setEditable(false);
        txtproductNameS.setEditable(false);
        
        
    }
   private void clearc() //clears text fields in create tab
    {
        txtproductID.setText("");
        txtproductName.setText("");
        txtproductPrice.setText("");  
    }
    
    private void clearm() //clears text fields in modify tab
    {
        txtproductIDM.setText("");
        txtproductNameM.setText("");
        txtproductPriceM.setText("");
    }
    
    private void cleard() //clears text fields in delete tab
    {
        txtproductIDD.setText("");
    }
    
    private void clears() //clears text fields in search tab
    {
        txtproductIDS.setText("");
        txtproductNameS.setText("");
        txtproductPriceS.setText("");
    }
private void downloadHardwareProducts()
    {
        String HardwareProduct;
        
        try
        {
            FileReader r = new FileReader(HardwareProductFile);
            BufferedReader reader = new BufferedReader(r);
            
            while ((HardwareProduct = reader.readLine()) != null)
            {
                if (HardwareProduct.length() > 0)
                {
                String pData[] = HardwareProduct.split(",");
                
                int id = Integer.valueOf(pData[0]);
                String hardwareName = pData[2];
                double price = Double.valueOf(pData[1]);
                
                HardwareProducts p = new HardwareProducts(id,  price, hardwareName);
                
                HardwareProductData.put(id, p);
                   
                }
            }
            reader.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "file error");
        }
    }
    
    private void uploadHardwareProducts(String HardwareProductFile)
    {
        String tempFile = "temp.dat";
        File oldfile = new File (HardwareProductFile);
        File newFile = new File (tempFile);
        oldfile.delete();
        File dump = new File(HardwareProductFile);
        newFile.renameTo(dump);
        
        try
        {
            FileWriter w = new FileWriter(HardwareProductFile, true);
            BufferedWriter writer = new BufferedWriter(w);
            
            for (Object key : HardwareProductData.keySet())
            {
                HardwareProducts value = (HardwareProducts) HardwareProductData.get(key);
                writer.write(value.toString());
                writer.newLine();
                
            }
                
                writer.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "File Error");
        }
    }
    private void downloadSoftwareProducts()
    {
        String SoftwareProducts;
        
        try
        {
            FileReader r = new FileReader(SoftwareProductFile);
            BufferedReader reader = new BufferedReader(r);
            
            while ((SoftwareProducts = reader.readLine()) != null)
            {
                if (SoftwareProducts.length() > 0)
                {
                String sData[] = SoftwareProducts.split(",");
                
                int id = Integer.valueOf(sData[0]);
                String softwareName = sData[1];
                double price = Double.valueOf(sData[2]);
                
                SoftwareProducts sw = new SoftwareProducts(id, price, softwareName);
               
                SoftwareProductData.put(id, sw);
                   
                }
            }
            reader.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "file error");
        }
    }
    
    private void uploadSoftwareProducts(String SoftwareProductFile)
    {
        String tempFile = "temp.dat";
        File oldfile = new File (SoftwareProductFile);
        File newFile = new File (tempFile);
        oldfile.delete();
        File dump = new File(SoftwareProductFile);
        newFile.renameTo(dump);
        
        try
        {
            FileWriter w = new FileWriter(SoftwareProductFile, true);
            BufferedWriter writer = new BufferedWriter(w);
            
            for (Object key : SoftwareProductData.keySet())
            {
                SoftwareProducts value = (SoftwareProducts) SoftwareProductData.get(key);
                writer.write(value.toString());
                writer.newLine();
                
            }
                
                writer.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "File Error");
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        jRadioButton1 = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtproductID = new javax.swing.JTextField();
        txtproductName = new javax.swing.JTextField();
        txtproductPrice = new javax.swing.JTextField();
        btnCreate = new javax.swing.JButton();
        btnCancelC = new javax.swing.JButton();
        jRadioButtonCreateSW = new javax.swing.JRadioButton();
        jRadioButtonCreateHW = new javax.swing.JRadioButton();
        btnCreate2 = new javax.swing.JButton();
        btnCancelC2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtproductNameM = new javax.swing.JTextField();
        txtproductPriceM = new javax.swing.JTextField();
        btnCancelM = new javax.swing.JButton();
        btnUpdateSW = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtproductIDM = new javax.swing.JTextField();
        jRadioButtonModifySW = new javax.swing.JRadioButton();
        jRadioButtonModifyHW = new javax.swing.JRadioButton();
        jLabel18 = new javax.swing.JLabel();
        btnUpdateHW = new javax.swing.JButton();
        btnCancelM2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        txtproductIDD = new javax.swing.JTextField();
        btnDeleteHW = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jRadioButtonDeleteHW = new javax.swing.JRadioButton();
        jRadioButtonDeleteSW = new javax.swing.JRadioButton();
        btnDeleteSW = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        txtproductIDS = new javax.swing.JTextField();
        btnSearchHW = new javax.swing.JButton();
        btnSearchSW = new javax.swing.JButton();
        btnClearSW = new javax.swing.JButton();
        btnClearHW = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtproductNameS = new javax.swing.JTextField();
        txtproductPriceS = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jRadioButtonSearchHW = new javax.swing.JRadioButton();
        jRadioButtonSearchSW = new javax.swing.JRadioButton();
        LookupSButton = new javax.swing.JButton();
        LookupHButton = new javax.swing.JButton();

        jRadioButton1.setText("jRadioButton1");

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Agency FB", 1, 36)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PRODUCTS.fw.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, -1, -1));

        jLabel10.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel10.setText("Category");

        jLabel11.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel11.setText("Product ID");

        jLabel12.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel12.setText("Product Name");

        jLabel13.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel13.setText("Product Price");

        txtproductID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtproductIDActionPerformed(evt);
            }
        });
        txtproductID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtproductIDKeyPressed(evt);
            }
        });

        txtproductName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtproductNameKeyPressed(evt);
            }
        });

        txtproductPrice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtproductPriceActionPerformed(evt);
            }
        });

        btnCreate.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnCreate.setText("CREATE");
        btnCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateActionPerformed(evt);
            }
        });

        btnCancelC.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnCancelC.setText("CANCEL");
        btnCancelC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelCActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButtonCreateSW);
        jRadioButtonCreateSW.setText("Software");
        jRadioButtonCreateSW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonCreateSWActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButtonCreateHW);
        jRadioButtonCreateHW.setText("Hardware");
        jRadioButtonCreateHW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonCreateHWActionPerformed(evt);
            }
        });

        btnCreate2.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnCreate2.setText("CREATE");
        btnCreate2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreate2ActionPerformed(evt);
            }
        });

        btnCancelC2.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnCancelC2.setText("CANCEL");
        btnCancelC2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelC2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel11))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel12))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jRadioButtonCreateHW)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtproductPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jRadioButtonCreateSW)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtproductID, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                                        .addComponent(txtproductName)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(btnCancelC))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(btnCancelC2)
                                            .addComponent(btnCreate2)
                                            .addComponent(btnCreate))))))
                        .addContainerGap(26, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jRadioButtonCreateHW)
                        .addComponent(btnCreate2))
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonCreateSW, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelC2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtproductID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))
                        .addGap(3, 3, 3))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCreate)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel13)
                        .addContainerGap(20, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtproductName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCancelC, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtproductPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jTabbedPane2.addTab("Create", jPanel1);

        jLabel14.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel14.setText("Product Name");

        jLabel15.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel15.setText("Product Price");

        txtproductNameM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtproductNameMActionPerformed(evt);
            }
        });
        txtproductNameM.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtproductNameMKeyPressed(evt);
            }
        });

        btnCancelM.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnCancelM.setText("CANCEL");
        btnCancelM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelMActionPerformed(evt);
            }
        });

        btnUpdateSW.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnUpdateSW.setText("UPDATE");
        btnUpdateSW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateSWActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel2.setText("Product ID");

        txtproductIDM.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtproductIDMKeyPressed(evt);
            }
        });

        buttonGroup2.add(jRadioButtonModifySW);
        jRadioButtonModifySW.setText("Software");
        jRadioButtonModifySW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonModifySWActionPerformed(evt);
            }
        });

        buttonGroup2.add(jRadioButtonModifyHW);
        jRadioButtonModifyHW.setText("Hardware");
        jRadioButtonModifyHW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonModifyHWActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel18.setText("Category");

        btnUpdateHW.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnUpdateHW.setText("UPDATE");
        btnUpdateHW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateHWActionPerformed(evt);
            }
        });

        btnCancelM2.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnCancelM2.setText("CANCEL");
        btnCancelM2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelM2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel18))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jRadioButtonModifySW)
                            .addComponent(jRadioButtonModifyHW)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtproductPriceM, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtproductNameM, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtproductIDM, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnCancelM)
                        .addContainerGap(16, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnCancelM2, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnUpdateSW)
                            .addComponent(btnUpdateHW))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnCancelM, btnCancelM2, btnUpdateHW, btnUpdateSW});

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtproductIDM, txtproductNameM, txtproductPriceM});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel18)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jRadioButtonModifyHW)
                        .addComponent(btnUpdateHW, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonModifySW)
                    .addComponent(btnCancelM2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(txtproductIDM, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtproductNameM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtproductPriceM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnUpdateSW)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCancelM)
                        .addGap(88, 88, 88))))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnCancelM, btnCancelM2, btnUpdateHW, btnUpdateSW});

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtproductIDM, txtproductNameM, txtproductPriceM});

        jTabbedPane2.addTab("Modify", jPanel2);

        jLabel16.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel16.setText("Product ID");

        txtproductIDD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtproductIDDKeyPressed(evt);
            }
        });

        btnDeleteHW.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnDeleteHW.setText("DELETE");
        btnDeleteHW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteHWActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel19.setText("Category");

        buttonGroup3.add(jRadioButtonDeleteHW);
        jRadioButtonDeleteHW.setText("Hardware");
        jRadioButtonDeleteHW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonDeleteHWActionPerformed(evt);
            }
        });

        buttonGroup3.add(jRadioButtonDeleteSW);
        jRadioButtonDeleteSW.setText("Software");
        jRadioButtonDeleteSW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonDeleteSWActionPerformed(evt);
            }
        });

        btnDeleteSW.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnDeleteSW.setText("DELETE");
        btnDeleteSW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteSWActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addGap(95, 95, 95)
                        .addComponent(txtproductIDD, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(178, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addGap(96, 96, 96)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jRadioButtonDeleteSW)
                            .addComponent(jRadioButtonDeleteHW))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnDeleteHW, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnDeleteSW, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(29, 29, 29))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnDeleteHW)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDeleteSW))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jRadioButtonDeleteHW)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jRadioButtonDeleteSW))
                        .addComponent(jLabel19)))
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txtproductIDD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(102, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Delete", jPanel3);

        jLabel17.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel17.setText("Product ID");

        txtproductIDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtproductIDSActionPerformed(evt);
            }
        });
        txtproductIDS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtproductIDSKeyPressed(evt);
            }
        });

        btnSearchHW.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnSearchHW.setText("SEARCH");
        btnSearchHW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchHWActionPerformed(evt);
            }
        });

        btnSearchSW.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnSearchSW.setText("SEARCH");
        btnSearchSW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchSWActionPerformed(evt);
            }
        });

        btnClearSW.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnClearSW.setText("CLEAR");
        btnClearSW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearSWActionPerformed(evt);
            }
        });

        btnClearHW.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        btnClearHW.setText("CLEAR");
        btnClearHW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearHWActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel3.setText("Product Name");

        jLabel4.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel4.setText("Product Price");

        txtproductPriceS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtproductPriceSActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Agency FB", 0, 18)); // NOI18N
        jLabel20.setText("Category");

        buttonGroup4.add(jRadioButtonSearchHW);
        jRadioButtonSearchHW.setText("Hardware");
        jRadioButtonSearchHW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonSearchHWActionPerformed(evt);
            }
        });

        buttonGroup4.add(jRadioButtonSearchSW);
        jRadioButtonSearchSW.setText("Software");
        jRadioButtonSearchSW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonSearchSWActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtproductPriceS, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel20)
                                .addGap(88, 88, 88)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jRadioButtonSearchSW)
                                    .addComponent(jRadioButtonSearchHW)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtproductIDS, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtproductNameS, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnSearchHW, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSearchSW, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnClearHW, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnClearSW, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(0, 43, Short.MAX_VALUE))
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnClearHW, btnClearSW, btnSearchHW, btnSearchSW});

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(54, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(btnSearchSW, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchHW)
                        .addGap(6, 6, 6)
                        .addComponent(btnClearHW)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnClearSW))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jRadioButtonSearchHW)
                            .addComponent(jLabel20))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRadioButtonSearchSW)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(txtproductIDS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtproductNameS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtproductPriceS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(25, 25, 25))
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnClearHW, btnClearSW, btnSearchHW, btnSearchSW});

        jPanel4Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtproductIDS, txtproductNameS, txtproductPriceS});

        jTabbedPane2.addTab("Search", jPanel4);

        getContentPane().add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 470, 290));

        LookupSButton.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        LookupSButton.setText("LOOKUP SOFTWARE PRODUCTS");
        LookupSButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LookupSButtonActionPerformed(evt);
            }
        });
        getContentPane().add(LookupSButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, -1, -1));

        LookupHButton.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        LookupHButton.setText("LOOKUP HARDWARE PRODUCTS");
        LookupHButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LookupHButtonActionPerformed(evt);
            }
        });
        getContentPane().add(LookupHButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, -1, -1));

        setSize(new java.awt.Dimension(654, 478));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void LookupSButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LookupSButtonActionPerformed
        new SoftwareProductsList().setVisible(true); 
    }//GEN-LAST:event_LookupSButtonActionPerformed

    private void btnCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateActionPerformed

        String Validation = txtproductID.getText();
        int productID = Integer.valueOf(txtproductID.getText());
        String softwareName = txtproductName.getText();
        double productPrice = Double.valueOf(txtproductPrice.getText());

        if (Validation.length() > 4 || Validation.length() < 4)
        {
            JOptionPane.showMessageDialog(ProductsMenu.this,
                "Product ID should be 4 characters");  
        }else if(SoftwareProductData.get(productID) != null){
            JOptionPane.showMessageDialog(ProductsMenu.this,
                "Product ID already exist, please try again");
        } 
        else
        {
            SoftwareProducts sw = new SoftwareProducts(productID,  productPrice, softwareName);// Creates software product Object with the needed variables
            SoftwareProductData.put(productID, sw);

            JOptionPane.showMessageDialog(null, "Software Product Saved");
            clearc();
            uploadSoftwareProducts(SoftwareProductFile);

        }
        

    }//GEN-LAST:event_btnCreateActionPerformed

    private void btnCancelCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelCActionPerformed

        clearc();
    }//GEN-LAST:event_btnCancelCActionPerformed

    private void btnCancelMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelMActionPerformed

        clearm();
    }//GEN-LAST:event_btnCancelMActionPerformed

    private void btnUpdateSWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateSWActionPerformed

        String Validation = txtproductIDM.getText();
        int productID = Integer.valueOf(txtproductIDM.getText());
        String softwareName = txtproductNameM.getText();
        double productPrice = Double.valueOf(txtproductPriceM.getText());

        if (Validation.length() > 4 || Validation.length() < 4)
        {
            JOptionPane.showMessageDialog(ProductsMenu.this,
                "Product ID should be 4 characters");  
        }else if(SoftwareProductData.get(productID) == null){
            JOptionPane.showMessageDialog(ProductsMenu.this,
                "Product ID does not exist, please try again");
        }
        else
        //Updates software product name and price to what user has input
        {
            SoftwareProducts sw = (SoftwareProducts) SoftwareProductData.get(productID);

            sw.modify(productPrice, softwareName);

            JOptionPane.showMessageDialog(null, "Software Product Updated");

            uploadSoftwareProducts(SoftwareProductFile);

            clearm();  
        }
        
    }//GEN-LAST:event_btnUpdateSWActionPerformed

    private void btnDeleteHWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteHWActionPerformed
//Deletes a Hardware object based on input ID
        int productID = Integer.valueOf(txtproductIDD.getText());
        if (HardwareProductData.get(productID)== null){
            JOptionPane.showMessageDialog(ProductsMenu.this, 
                                "ProductID does not exist, please try again");  
        }else{
            HardwareProductData.remove(productID);
            JOptionPane.showMessageDialog(null, "Hardware Product Deleted");
        }

   

        uploadHardwareProducts(HardwareProductFile);

        cleard();
    }//GEN-LAST:event_btnDeleteHWActionPerformed

    private void btnSearchHWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchHWActionPerformed
 //Searches for Hardware product by ID input and returns corresponding name and price to text fields
        String Validation = txtproductIDS.getText();
       
        int productID = Integer.valueOf(txtproductIDS.getText());
       
        if (Validation.length() > 4 || Validation.length() < 4)
        { 
          JOptionPane.showMessageDialog(ProductsMenu.this, 
                                "Product ID should be 4 characters");  
        }else if (HardwareProductData.get(productID)== null){
            JOptionPane.showMessageDialog(ProductsMenu.this, 
                                "ProductID does not exist, please try again");  
        }
        else
        {
            HardwareProducts p = (HardwareProducts) HardwareProductData.get(productID);
            
            txtproductIDS.setEditable(false);
            
            txtproductNameS.setVisible(true);
            txtproductNameS.setText(p.getHardwareName()); 
            
            txtproductPriceS.setVisible(true);
            txtproductPriceS.setText(String.valueOf(p.getProductPrice()));
            
        }  
    }//GEN-LAST:event_btnSearchHWActionPerformed

    private void btnClearHWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearHWActionPerformed

       clears();

    }//GEN-LAST:event_btnClearHWActionPerformed

    private void txtproductIDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtproductIDSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtproductIDSActionPerformed

    private void txtproductIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtproductIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtproductIDActionPerformed

    private void txtproductPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtproductPriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtproductPriceActionPerformed

    private void txtproductNameMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtproductNameMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtproductNameMActionPerformed

    private void txtproductPriceSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtproductPriceSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtproductPriceSActionPerformed

    private void jRadioButtonCreateSWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonCreateSWActionPerformed
      
        txtproductID.setEditable(true);
        txtproductName.setEditable(true);
        txtproductPrice.setEditable(true);
        
        btnCreate.setVisible(true);
        btnCancelC.setVisible(true);
        LookupSButton.setVisible(true);
        
        btnCreate2.setVisible(false);
        btnCancelC2.setVisible(false);
        LookupHButton.setVisible(false);
    }//GEN-LAST:event_jRadioButtonCreateSWActionPerformed

    private void jRadioButtonModifySWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonModifySWActionPerformed
        txtproductIDM.setEditable(true);
        txtproductNameM.setEditable(true);
        txtproductPriceM.setEditable(true);
        
        btnUpdateSW.setVisible(true);
        btnCancelM.setVisible(true);
        LookupSButton.setVisible(true);
        
        btnUpdateHW.setVisible(false);
        btnCancelM2.setVisible(false);
        LookupHButton.setVisible(false);        LookupHButton.setVisible(false);        LookupHButton.setVisible(false);    }//GEN-LAST:event_jRadioButtonModifySWActionPerformed

    private void jRadioButtonDeleteSWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonDeleteSWActionPerformed
        btnDeleteHW.setVisible(false);
        btnDeleteSW.setVisible(true);
        
        txtproductIDD.setEditable(true);
        
        LookupHButton.setVisible(false);
        LookupSButton.setVisible(true);
    }//GEN-LAST:event_jRadioButtonDeleteSWActionPerformed

    private void jRadioButtonSearchSWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonSearchSWActionPerformed
        btnSearchSW.setVisible(true);
        btnClearSW.setVisible(true);
        
        btnSearchHW.setVisible(false);
        btnClearHW.setVisible(false);
        
        LookupHButton.setVisible(false);
        LookupSButton.setVisible(true);

        txtproductIDS.setEditable(true);
        
            }//GEN-LAST:event_jRadioButtonSearchSWActionPerformed

    private void jRadioButtonCreateHWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonCreateHWActionPerformed
        txtproductID.setEditable(true);
        txtproductName.setEditable(true);
        txtproductPrice.setEditable(true);
        
        btnCreate2.setVisible(true);
        btnCancelC2.setVisible(true);
        LookupHButton.setVisible(true);
        
        btnCreate.setVisible(false);
        btnCancelC.setVisible(false);
        LookupSButton.setVisible(false);
    }//GEN-LAST:event_jRadioButtonCreateHWActionPerformed

    private void jRadioButtonSearchHWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonSearchHWActionPerformed
        btnSearchHW.setVisible(true);
        btnClearHW.setVisible(true);
        
        btnSearchSW.setVisible(false);
        btnClearSW.setVisible(false);
        
        LookupSButton.setVisible(false);
        LookupHButton.setVisible(true);
        
        txtproductIDS.setEditable(true);

           }//GEN-LAST:event_jRadioButtonSearchHWActionPerformed

    private void btnDeleteSWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteSWActionPerformed
        int productID = Integer.valueOf(txtproductIDD.getText());
        
        
        
        if (SoftwareProductData.get(productID)== null){
            JOptionPane.showMessageDialog(ProductsMenu.this, 
                                "ProductID does not exist, please try again");  
        }
        else{
            SoftwareProductData.remove(productID);
            JOptionPane.showMessageDialog(null, "Software Product Deleted");
        }

        

        uploadSoftwareProducts(SoftwareProductFile);

        cleard();
    }//GEN-LAST:event_btnDeleteSWActionPerformed

    private void jRadioButtonDeleteHWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonDeleteHWActionPerformed
        btnDeleteHW.setVisible(true);
        btnDeleteSW.setVisible(false);
        
        txtproductIDD.setEditable(true);
        
        LookupHButton.setVisible(true);
        LookupSButton.setVisible(false);

    }//GEN-LAST:event_jRadioButtonDeleteHWActionPerformed

    private void btnCreate2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreate2ActionPerformed
  //Creates new software product based off user input
        String Validation = txtproductID.getText();
        int productID = Integer.valueOf(txtproductID.getText());
        String HardwareName = txtproductName.getText();
        double productPrice = Double.valueOf(txtproductPrice.getText());

        if (Validation.length() > 4 || Validation.length() < 4)
        {
            JOptionPane.showMessageDialog(ProductsMenu.this,
                "Product ID should be 4 characters");  
        }else if (HardwareProductData.get(productID)!= null){
            JOptionPane.showMessageDialog(ProductsMenu.this, 
                                "ProductID already exist, please try again");  
        }
        else
        {
            HardwareProducts p = new HardwareProducts(productID,  productPrice, HardwareName);// Creates software product Object with the needed variables
            HardwareProductData.put(productID, p);

            JOptionPane.showMessageDialog(null, "Hardware Product Saved");
            clearc();
            uploadHardwareProducts(HardwareProductFile);

        }
    }//GEN-LAST:event_btnCreate2ActionPerformed

    private void btnCancelC2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelC2ActionPerformed
          
        clearc();
    }//GEN-LAST:event_btnCancelC2ActionPerformed

    private void LookupHButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LookupHButtonActionPerformed
        new HardwareProductsList().setVisible(true); 
    }//GEN-LAST:event_LookupHButtonActionPerformed

    private void jRadioButtonModifyHWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonModifyHWActionPerformed
        txtproductIDM.setEditable(true);
        txtproductNameM.setEditable(true);
        txtproductPriceM.setEditable(true);
        
        btnUpdateHW.setVisible(true);
        btnCancelM2.setVisible(true);
        LookupHButton.setVisible(true);
        
        btnUpdateSW.setVisible(false);
        btnCancelM.setVisible(false);
        LookupSButton.setVisible(false);        LookupSButton.setVisible(false);        LookupSButton.setVisible(false);    }//GEN-LAST:event_jRadioButtonModifyHWActionPerformed

    private void btnUpdateHWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateHWActionPerformed
  //Updates hardware product name and price to what user has input      
        String Validation = txtproductIDM.getText();
        int productID = Integer.valueOf(txtproductIDM.getText());
        String hardwareName = txtproductNameM.getText();
        double productPrice = Double.valueOf(txtproductPriceM.getText());

        if (Validation.length() > 4 || Validation.length() < 4)
        {
            JOptionPane.showMessageDialog(ProductsMenu.this,
                "Product ID should be 4 characters");  
        }else if (HardwareProductData.get(productID)== null){
            JOptionPane.showMessageDialog(ProductsMenu.this, 
                                "ProductID does not exist, please try again");  
        }
        else
        {
            HardwareProducts p = (HardwareProducts) HardwareProductData.get(productID);
        
            p.modify(hardwareName, productPrice);
        
            JOptionPane.showMessageDialog(null, "Hardware Product Changed");
            
            uploadHardwareProducts(HardwareProductFile);
            
            clearm();
        }
        
    }//GEN-LAST:event_btnUpdateHWActionPerformed

    private void btnCancelM2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelM2ActionPerformed
       
        clearm();
    }//GEN-LAST:event_btnCancelM2ActionPerformed

    private void btnSearchSWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchSWActionPerformed
 //Searches for Software product based off input ID and returns 
        String Validation = txtproductIDS.getText();
       
        int productID = Integer.valueOf(txtproductIDS.getText());
       
        if (Validation.length() > 4 || Validation.length() < 4)
        { 
          JOptionPane.showMessageDialog(ProductsMenu.this, 
                                "Product ID should be 4 characters");   
        }else if (SoftwareProductData.get(productID)== null){
            JOptionPane.showMessageDialog(ProductsMenu.this, 
                                "ProductID does not exist, please try again");  
        }
        
        else
        {
            SoftwareProducts p = (SoftwareProducts) SoftwareProductData.get(productID);
            
            txtproductIDS.setEditable(false);
            
            txtproductNameS.setVisible(true);
            txtproductNameS.setText(p.getSoftwareName()); 
            
            txtproductPriceS.setVisible(true);
            txtproductPriceS.setText(String.valueOf(p.getProductPrice()));
            
        }
    }//GEN-LAST:event_btnSearchSWActionPerformed

    private void btnClearSWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearSWActionPerformed
        clears();
    }//GEN-LAST:event_btnClearSWActionPerformed

    private void txtproductIDMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtproductIDMKeyPressed
        char c = evt.getKeyChar();
        if (Character.isDigit(c)|| Character.isISOControl(c)){
            txtproductIDM.setEditable(true);
        }else{ 
            txtproductIDM.setEditable(false);
        
     }     
    }//GEN-LAST:event_txtproductIDMKeyPressed

    private void txtproductNameMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtproductNameMKeyPressed
        char c = evt.getKeyChar();
        if (Character.isLetter(c)||Character.isWhitespace(c)|| Character.isISOControl(c)){
            txtproductNameM.setEditable(true);
        }else{ 
            txtproductNameM.setEditable(false);
        
     } 
    }//GEN-LAST:event_txtproductNameMKeyPressed

    private void txtproductIDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtproductIDKeyPressed
        char c = evt.getKeyChar();
        if (Character.isDigit(c)|| Character.isISOControl(c)){
            txtproductID.setEditable(true);
        }else{ 
            txtproductID.setEditable(false);
        
     }
    }//GEN-LAST:event_txtproductIDKeyPressed

    private void txtproductNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtproductNameKeyPressed
        char c = evt.getKeyChar();
        if (Character.isLetter(c)||Character.isWhitespace(c)|| Character.isISOControl(c)){
            txtproductName.setEditable(true);
        }else{ 
            txtproductName.setEditable(false);
        
     } 
    }//GEN-LAST:event_txtproductNameKeyPressed

    private void txtproductIDDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtproductIDDKeyPressed
        char c = evt.getKeyChar();
        if (Character.isDigit(c)|| Character.isISOControl(c)){
            txtproductIDD.setEditable(true);
        }else{ 
            txtproductIDD.setEditable(false);
        
     }
    }//GEN-LAST:event_txtproductIDDKeyPressed

    private void txtproductIDSKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtproductIDSKeyPressed
       char c = evt.getKeyChar();
        if (Character.isDigit(c)|| Character.isISOControl(c)){
            txtproductIDS.setEditable(true);
        }else{ 
            txtproductIDS.setEditable(false);
        
     }
    }//GEN-LAST:event_txtproductIDSKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ProductsMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ProductsMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ProductsMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ProductsMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProductsMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LookupHButton;
    private javax.swing.JButton LookupSButton;
    private javax.swing.JButton btnCancelC;
    private javax.swing.JButton btnCancelC2;
    private javax.swing.JButton btnCancelM;
    private javax.swing.JButton btnCancelM2;
    private javax.swing.JButton btnClearHW;
    private javax.swing.JButton btnClearSW;
    private javax.swing.JButton btnCreate;
    private javax.swing.JButton btnCreate2;
    private javax.swing.JButton btnDeleteHW;
    private javax.swing.JButton btnDeleteSW;
    private javax.swing.JButton btnSearchHW;
    private javax.swing.JButton btnSearchSW;
    private javax.swing.JButton btnUpdateHW;
    private javax.swing.JButton btnUpdateSW;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButtonCreateHW;
    private javax.swing.JRadioButton jRadioButtonCreateSW;
    private javax.swing.JRadioButton jRadioButtonDeleteHW;
    private javax.swing.JRadioButton jRadioButtonDeleteSW;
    private javax.swing.JRadioButton jRadioButtonModifyHW;
    private javax.swing.JRadioButton jRadioButtonModifySW;
    private javax.swing.JRadioButton jRadioButtonSearchHW;
    private javax.swing.JRadioButton jRadioButtonSearchSW;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTextField txtproductID;
    private javax.swing.JTextField txtproductIDD;
    private javax.swing.JTextField txtproductIDM;
    private javax.swing.JTextField txtproductIDS;
    private javax.swing.JTextField txtproductName;
    private javax.swing.JTextField txtproductNameM;
    private javax.swing.JTextField txtproductNameS;
    private javax.swing.JTextField txtproductPrice;
    private javax.swing.JTextField txtproductPriceM;
    private javax.swing.JTextField txtproductPriceS;
    // End of variables declaration//GEN-END:variables
}
